﻿CREATE TABLE [dbo].[adreslocatie] (
    [id] INT          NOT NULL,
    [x]  DECIMAL (18) NOT NULL,
    [y]  DECIMAL (18) NOT NULL,
    PRIMARY KEY CLUSTERED ([id] ASC)
);

